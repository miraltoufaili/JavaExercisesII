class Looping
{
   public static void main(String[] args)
   {
     for (int j = 0; j < 5; j++)
     
     {
      
      System.out.println (" j + 4");
      
     }


   }
   
}
 
 