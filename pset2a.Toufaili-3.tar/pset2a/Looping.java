//methodA 

class Looping
{
   public static void main(String[] args)
   {
    
     for (int j = 0; j < 5; j++)
     
     {
      
      int x = -3 + 4*j;
      System.out.println (x);
      
     }


   }
   
}
 
 
 
 //methodB
 
 class Looping
{
   public static void main(String[] args)
   {
    
     for (int j = -3; j <=13; j += 4)
     
     {
      
     
      System.out.println (j);
      
     }


   }
   
}



//MethodC 

class Looping
{
   public static void main(String[] args)
   {
    
    
     while (j <=13 )
     {
         int j = -3;
         
        System.out.println (j);
        
        j +=4;
      
     }


   }
   
}
 
 