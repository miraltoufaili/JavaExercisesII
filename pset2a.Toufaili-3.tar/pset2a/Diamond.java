class Diamond
{
    public static void main(String[] args)
        {
            System.out.println("   " + "D");
            System.out.println("  " + "I" + " " + "I");
            System.out.println(" " + "A" + "   " + "A");
            System.out.println("M"+ "     "+ "M");
            System.out.println(" " + "O" + "   " + "O");
            System.out.println("  " + "N" + " " + "N");
            System.out.println("   " + "D");
              
        }
}