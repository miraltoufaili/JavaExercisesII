public class Kalvin
     {
         public static void main(String [] args)
         {
             double farenheit = 212.0;
             double k = (5.0/9.0) * (farenheit-32.0) + 273.16;
             System.out.println("Kelvin equivalent = " + k);
         }
}
